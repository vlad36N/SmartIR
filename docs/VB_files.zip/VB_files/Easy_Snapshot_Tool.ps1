    #Generated Form Function
    function GenerateForm {
    ########################################################################
    #
    # Easy Snapshot Tool for VMware
    # - GUI based tool
    # - Centralised view of all snapshots in a vCenter server
    # - Create and delete snapshots of multiple VMs at the SAME time
    ########################################################################
     
    #region Import the Assemblies
    [reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
    [reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
    #endregion
     
    #region Generated Form Objects
    $EasySnapForm = New-Object System.Windows.Forms.Form
    $FormHeader = new-object System.Windows.Forms.Label
    $vCenterLabel = New-Object System.Windows.Forms.Label
    $VCComboBox = New-Object System.Windows.Forms.ComboBox
    $LoginBtn = New-Object System.Windows.Forms.Button
    $RefreshBtn = New-Object System.Windows.Forms.Button
    $ListSnapBtn = New-Object System.Windows.Forms.Button
    $CreateSnapBtn = New-Object System.Windows.Forms.Button
    $SnapshotlistView = New-Object System.Windows.Forms.ListView
    $DeleteSnapBtn = New-Object System.Windows.Forms.Button
    $VM = New-Object System.Windows.Forms.ColumnHeader
    $SnapName = New-Object System.Windows.Forms.ColumnHeader
    $Description = New-Object System.Windows.Forms.ColumnHeader
    $Created = New-Object System.Windows.Forms.ColumnHeader
    $ResetBtn = New-Object System.Windows.Forms.Button
    $ExitBtn = New-Object System.Windows.Forms.Button
    $InitialFormWindowState1 = New-Object System.Windows.Forms.FormWindowState
    #endregion Generated Form Objects
     
    #----------------------------------------------
    #Generated Event Script Blocks
    #----------------------------------------------
    #Provide Custom Code for events specified in PrimalForms.
    $userName = Read-Host 'What is your username?'
    $passwd = Read-Host ("Password for " + $userName) -AsSecureString:$true
    $cred = New-Object System.Management.Automation.PSCredential -ArgumentList $userName,$passwd
         
    $LoginBtn_Click=
    {
    If ($VCComboBox.SelectedItem -eq $null)
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show("Please choose a vCenter Server from the drop-down list.")
    }
    Else
    {
    #TODO: Place custom script here
    If ((Get-PSSnapin "VMware.VimAutomation.Core" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "VMware.VimAutomation.Core"
    }
    #Connect to vCenter
    $vCenterName = $VCComboBox.SelectedItem.ToString()
    Connect-VIServer $vCenterName  -Credential $cred -ErrorAction SilentlyContinue
    If (!$?)
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show($($error[0]))
    }
    Else
    {     
    $VCComboBox.Enabled = $false
    $LoginBtn.Enabled = $false
    $DeleteSnapBtn.Enabled = $true
    $Refreshbtn.Enabled = $true
    $Resetbtn.Enabled = $true
    $ListSnapBtn.Enabled = $true
    $CreateSnapBtn.Enabled = $true
     
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show("You are now connected to $vCenterName.")
     
    $OnLoadForm_StateCorrection=
    {#Correct the initial state of the form to prevent the .Net maximized form issue
            $EasySnapForm.WindowState = $InitialFormWindowState1
    }
    }
    }
     
    $DeleteSnapBtn_OnClick=
    {
    #TODO: Place custom script here
    $CheckedSnapshots = $SnapshotlistView.CheckedItems
     
    If($CheckedSnapshots.count -eq 0)
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show('No Snapshot Selected.')
    }
    Else
    {
    foreach($CheckedSnapshot in $CheckedSnapshots){
    $VMName = $CheckedSnapshot.SubItems[0].Text
    $SnapshotName = $CheckedSnapshot.SubItems[1].Text
    Get-VM -Name $VMName | Get-Snapshot | Where{$_.Name -eq $SnapshotName} | remove-snapshot -Confirm:$false -RunAsync
    $SnapshotlistView.Items.RemoveAt($SnapshotlistView.Items.IndexOf($CheckedSnapshot))
    $SnapshotlistView.refresh()
    }
    }
    }
    } 
    $RefreshBtn_OnClick=
    {
    #TODO: Place custom script here
    $SnapshotlistView.Items.Clear()
     
    Get-View -ViewType VirtualMachine -Property Name,Snapshot -SearchRoot(Get-Datacenter | get-view).MoRef `
    -Filter @{"Snapshot"="VMware.Vim.VirtualMachineSnapshotInfo"} | foreach-object {
        $vmname = $_.Name
        (Get-View -Id $_.MoRef -Property Snapshot).Snapshot.RootSnapshotList | foreach-object {
                $Item_VM = New-Object System.Windows.Forms.ListViewItem($vmname)
                $Item_Snapshot = $Item_VM.SubItems.Add($_.Name)
                $Item_Created = $Item_VM.SubItems.Add($_.CreateTime.ToString("yyyy/MM/dd"))
                           
                $Item_ArrDesc = ($_.Description).split("_")
                If ($Item_ArrDesc[0] -ne $null)
                {
                    $Item_CreatorID = $Item_VM.SubItems.Add($Item_ArrDesc[0])
                }
                Else
                {
                $Item_CreatorID = $Item_VM.SubItems.Add("")
                }
     
                If ($Item_ArrDesc[1] -ne $null)
                {
                $Item_ChangeNo = $Item_VM.SubItems.Add($Item_ArrDesc[1])
                }
                Else
                {
                $Item_ChangeNo = $Item_VM.SubItems.Add("")
                }
               
                If ($Item_ArrDesc[2] -ne $null)
                {
                $Item_DeletionDate = $Item_VM.SubItems.Add($Item_ArrDesc[2])
                }
                Else
                {
                $Item_DeletionDate = $Item_VM.SubItems.Add("")
                }
               
                $SnapDaysOld = (new-timespan -start (Get-Date $_.CreateTime.ToString("yyyy/MM/dd"))).Days
                If($SnapDaysOld -lt 10)
                {
                $Item_DaysOld = $Item_VM.SubItems.Add("0" + $SnapDaysOld)
                }
                Else{
                $Item_DaysOld = $Item_VM.SubItems.Add($SnapDaysOld)
                    If($SnapDaysOld -ge 15)
                    {
                    $Item_VM.UseItemStyleForSubItems = $False
                    $Item_VM.BackColor = "Red"
                    $Item_Snapshot.BackColor = "Red"
                    $Item_Created.BackColor = "Red"
                    $Item_CreatorID.BackColor = "Red"
                    $Item_ChangeNo.BackColor = "Red"
                    $Item_DeletionDate.BackColor = "Red"
                    $Item_DaysOld.BackColor = "Red"
                    }
                }
               
                $SnapshotlistView.Items.Add($Item_VM)
        }
      }
    }
     
    $ListSnapBtn_OnClick=
    {
    #TODO: Place custom script here
    If (!$?)
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show($($error[0]))
    }
    Else
    {
    $SnapshotlistView.Items.Clear()
     
    Get-View -ViewType VirtualMachine -Property Name,Snapshot -SearchRoot(Get-Datacenter | get-view).MoRef `
    -Filter @{"Snapshot"="VMware.Vim.VirtualMachineSnapshotInfo"} | foreach-object {
        $vmname = $_.Name
        (Get-View -Id $_.MoRef -Property Snapshot).Snapshot.RootSnapshotList | foreach-object {
                $Item_VM = New-Object System.Windows.Forms.ListViewItem($vmname)
                $Item_Snapshot = $Item_VM.SubItems.Add($_.Name)
                $Item_Created = $Item_VM.SubItems.Add($_.CreateTime.ToString("yyyy/MM/dd"))
                           
                $Item_ArrDesc = ($_.Description).split("_")
                If ($Item_ArrDesc[0] -ne $null)
                {
                    $Item_CreatorID = $Item_VM.SubItems.Add($Item_ArrDesc[0])
                }
                Else
                {
                $Item_CreatorID = $Item_VM.SubItems.Add("")
                }
     
                If ($Item_ArrDesc[1] -ne $null)
                {
                $Item_ChangeNo = $Item_VM.SubItems.Add($Item_ArrDesc[1])
                }
                Else
                {
                $Item_ChangeNo = $Item_VM.SubItems.Add("")
                }
               
                If ($Item_ArrDesc[2] -ne $null)
                {
                $Item_DeletionDate = $Item_VM.SubItems.Add($Item_ArrDesc[2])
                }
                Else
                {
                $Item_DeletionDate = $Item_VM.SubItems.Add("")
                }
               
                $SnapDaysOld = (new-timespan -start (Get-Date $_.CreateTime.ToString("yyyy/MM/dd"))).Days
                If($SnapDaysOld -lt 10)
                {
                $Item_DaysOld = $Item_VM.SubItems.Add("0" + $SnapDaysOld)
                }
                Else{
                $Item_DaysOld = $Item_VM.SubItems.Add($SnapDaysOld)
                    If($SnapDaysOld -ge 15)
                    {
                    $Item_VM.UseItemStyleForSubItems = $False
                    $Item_VM.BackColor = "Red"
                    $Item_Snapshot.BackColor = "Red"
                    $Item_Created.BackColor = "Red"
                    $Item_CreatorID.BackColor = "Red"
                    $Item_ChangeNo.BackColor = "Red"
                    $Item_DeletionDate.BackColor = "Red"
                    $Item_DaysOld.BackColor = "Red"
                    }
                }
               
                $SnapshotlistView.Items.Add($Item_VM)
        }
      }
    }
    }
     
    $CreateSnapBtn_OnClick=
    {
    #TODO: Place custom script here
    GenerateSnapForm
    }
     
    $ResetBtn_OnClick=
    {
    #TODO: Place custom script here
     
    #Disconnect from vCenter server
    Disconnect-VIServer -Confirm:$false
     
    $SnapshotlistView.Items.Clear()
    $VCComboBox.Enabled = $true
    $VCComboBox.Text = ""
    $LoginBtn.Enabled = $true
    $DeleteSnapBtn.Enabled = $false
    $Refreshbtn.Enabled = $false
    $Resetbtn.Enabled = $false
    $ListSnapBtn.Enabled = $false
    $CreateSnapBtn.Enabled = $false
    }
     
$comparerClassString = @"
     
   using System;
   using System.Windows.Forms;
   using System.Drawing;
   using System.Collections;
    
   public class ListViewItemComparer : IComparer
   {
    private int col;
    public ListViewItemComparer()
    {
     col = 0;
    }
    public ListViewItemComparer(int column)
    {
     col = column;
    }
    public int Compare(object x, object y)
    {
      return String.Compare(
      ((ListViewItem)x).SubItems[col].Text,
      ((ListViewItem)y).SubItems[col].Text);
    }
  }
     
"@
#---------------------------------------     
    # Add the comparer class
     
    Add-Type -TypeDefinition $comparerClassString `
      -ReferencedAssemblies (`
        'System.Windows.Forms', 'System.Drawing')
     
    # Add the event to the ListView ColumnClick event
     
    $columnClick =
    {
      $SnapshotlistView.ListViewItemSorter = `
        New-Object ListViewItemComparer($_.Column)
    }
     
    $ExitBtn_OnClick=
    {
    #TODO: Place custom script here
    If ($VCComboBox.Text -ne "")
    {
            #Disconnect from vCenter server
            Disconnect-VIServer -Confirm:$false
    }
            #Close Form
            $EasySnapForm.close()
    }
     
    #----------------------------------------------
    #region Generated Form Code
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 462
    $System_Drawing_Size.Width = 734
    $EasySnapForm.ClientSize = $System_Drawing_Size
    $EasySnapForm.DataBindings.DefaultDataSourceUpdateMode = 0
    $EasySnapForm.Name = "EasySnapForm"
    $EasySnapForm.Text = "Easy Snapshot Tool"
    $EasySnapForm.StartPosition = "CenterScreen"
    $EasySnapForm.FormBorderStyle = "FixedDialog"
    $EasySnapForm.MaximizeBox = $false
    $EasySnapForm.MinimizeBox = $false
     
    #Start Form Header
    $FormHeader.Font = new-object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Bold)
    $FormHeader.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $FormHeader.Text = 'Easy Snapshot Tool'
    $FormHeader.Location = new-object System.Drawing.Point(15,15)
    $FormHeader.Size = new-object System.Drawing.Size(300, 20)
     
    $EasySnapForm.Controls.Add($FormHeader)
    #End Form Header
     
    # Start vCenter Server Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 120
    $System_Drawing_Size.Height = 20
    $vCenterLabel.Size = $System_Drawing_Size
    $vCenterLabel.Font = new-object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Bold)
    $vCenterLabel.Text = 'vCenter Server:'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 15
    $System_Drawing_Point.Y = 50
    $vCenterLabel.Location = $System_Drawing_Point
    $vCenterLabel.DataBindings.DefaultDataSourceUpdateMode = 0
    $vCenterLabel.Name = 'vCenterLabel'
     
    $EasySnapForm.Controls.Add($vCenterLabel)
    # End vCenter Server Label
     
    # Start vCenter ComboBox
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 120
    $System_Drawing_Size.Height = 20
    $VCComboBox.Size = $System_Drawing_Size
    $VCComboBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $VCComboBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $VCComboBox.Name = 'VCComboBox'
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 135
    $System_Drawing_Point.Y = 50
    $VCComboBox.Location = $System_Drawing_Point
    $VCComboBox.TabIndex = 0
     
    #vShpere names
    #$VCNames = @('VCServer01','VCServer02','VCServer03')
    $VCNames = @('VSPHERE50', 'Vspherei', 'Vsphere', 'Vicenter', 'ESX', 'Itplab-Dserv')
    foreach($VCName in $VCNames)
    {
      $VCComboBox.Items.add($VCName)
    }
     
    $EasySnapForm.Controls.Add($VCComboBox)
    # End vCenter ComboBox
     
    # Start Login Button
    $LoginBtn.TabIndex = 1
    $LoginBtn.Name = 'LoginBtn'
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 95
    $System_Drawing_Size.Height = 22
    $LoginBtn.Size = $System_Drawing_Size
    $LoginBtn.UseVisualStyleBackColor = $True
    $LoginBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $LoginBtn.Text = 'Connect'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 260
    $System_Drawing_Point.Y = 50
    $LoginBtn.Location = $System_Drawing_Point
    $LoginBtn.DataBindings.DefaultDataSourceUpdateMode = 0
    $LoginBtn.add_Click($LoginBtn_Click)
     
    $EasySnapForm.Controls.Add($LoginBtn)
    # End Login Button
     
    #Start Create Snapshot Button
    $CreateSnapBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 622
    $System_Drawing_Point.Y = 50
    $CreateSnapBtn.Location = $System_Drawing_Point
    $CreateSnapBtn.Name = "CreateSnapBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $CreateSnapBtn.Size = $System_Drawing_Size
    $CreateSnapBtn.TabIndex = 6
    $CreateSnapBtn.Text = "Create Snapshots"
    $CreateSnapBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $CreateSnapBtn.UseVisualStyleBackColor = $True
    $CreateSnapBtn.Enabled = $false
    $CreateSnapBtn.add_Click($CreateSnapBtn_OnClick)
     
    $EasySnapForm.Controls.Add($CreateSnapBtn)
    #End Create Snapshot Button
     
    #Start List Snapshot Button
    $ListSnapBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 515
    $System_Drawing_Point.Y = 50
    $ListSnapBtn.Location = $System_Drawing_Point
    $ListSnapBtn.Name = "ListSnapBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $ListSnapBtn.Size = $System_Drawing_Size
    $ListSnapBtn.TabIndex = 6
    $ListSnapBtn.Text = "List Snapshots"
    $ListSnapBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $ListSnapBtn.UseVisualStyleBackColor = $True
    $ListSnapBtn.Enabled = $false
    $ListSnapBtn.add_Click($ListSnapBtn_OnClick)
     
    $EasySnapForm.Controls.Add($ListSnapBtn)
    #End List Snapshot Button
     
    #Start Snapshot List
    $SnapshotlistView.AllowColumnReorder = $True
     
    $SnapshotlistView.CheckBoxes = $True
    $System_Windows_Forms_ColumnHeader_45 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_45.Name = "VM"
    $System_Windows_Forms_ColumnHeader_45.Text = "VM Name"
    $System_Windows_Forms_ColumnHeader_45.Width = 100
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_45)|Out-Null
    $System_Windows_Forms_ColumnHeader_46 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_46.Name = "SnapName"
    $System_Windows_Forms_ColumnHeader_46.Text = "Snapshot Name"
    $System_Windows_Forms_ColumnHeader_46.Width = 200
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_46)|Out-Null
    $System_Windows_Forms_ColumnHeader_47 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_47.Name = "CreationDate"
    $System_Windows_Forms_ColumnHeader_47.Text = "Created On"
    $System_Windows_Forms_ColumnHeader_47.Width = 80
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_47)|Out-Null
    $System_Windows_Forms_ColumnHeader_48 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_48.Name = "CreatorID"
    $System_Windows_Forms_ColumnHeader_48.Text = "Created By"
    $System_Windows_Forms_ColumnHeader_48.Width = 80
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_48)|Out-Null
     
    $System_Windows_Forms_ColumnHeader_49 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_49.Name = "ChangeNo"
    $System_Windows_Forms_ColumnHeader_49.Text = "Change No"
    $System_Windows_Forms_ColumnHeader_49.Width = 80
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_49)|Out-Null
    $System_Windows_Forms_ColumnHeader_50 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_50.Name = "DeletionDate"
    $System_Windows_Forms_ColumnHeader_50.Text = "Deletion Date"
    $System_Windows_Forms_ColumnHeader_50.Width = 80
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_50)|Out-Null
    $System_Windows_Forms_ColumnHeader_51 = New-Object System.Windows.Forms.ColumnHeader
    $System_Windows_Forms_ColumnHeader_51.Name = "DaysOld"
    $System_Windows_Forms_ColumnHeader_51.Text = "Days Old"
    $System_Windows_Forms_ColumnHeader_51.Width = 60
     
    $SnapshotlistView.Columns.Add($System_Windows_Forms_ColumnHeader_51)|Out-Null
     
    $SnapshotlistView.DataBindings.DefaultDataSourceUpdateMode = 0
    $SnapshotlistView.FullRowSelect = $True
    $SnapshotlistView.GridLines = $True
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 13
    $System_Drawing_Point.Y = 90
    $SnapshotlistView.Location = $System_Drawing_Point
    $SnapshotlistView.Name = "SnapshotlistView"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 330
    $System_Drawing_Size.Width = 709
    $SnapshotlistView.Size = $System_Drawing_Size
    $SnapshotlistView.TabIndex = 7
    $SnapshotlistView.UseCompatibleStateImageBehavior = $False
    $SnapshotlistView.View = 'Details'
    $SnapshotlistView.Sorting = 'Ascending'
     
    $SnapshotlistView.add_ColumnClick($ColumnClick)
     
    $EasySnapForm.Controls.Add($SnapshotlistView)
    #End Snapshot List
     
    #Start Delete Button
    $DeleteSnapBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 15
    $System_Drawing_Point.Y = 427
    $DeleteSnapBtn.Location = $System_Drawing_Point
    $DeleteSnapBtn.Name = "DeleteSnapBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $DeleteSnapBtn.Size = $System_Drawing_Size
    $DeleteSnapBtn.TabIndex = 6
    $DeleteSnapBtn.Text = "Delete"
    $DeleteSnapBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $DeleteSnapBtn.UseVisualStyleBackColor = $True
    $DeleteSnapBtn.Enabled = $false
    $DeleteSnapBtn.add_Click($DeleteSnapBtn_OnClick)
     
    $EasySnapForm.Controls.Add($DeleteSnapBtn)
    #End Delete Button
     
    #Start Refresh Button
    $RefreshBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 120
    $System_Drawing_Point.Y = 427
    $RefreshBtn.Location = $System_Drawing_Point
    $RefreshBtn.Name = "RefreshBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $RefreshBtn.Size = $System_Drawing_Size
    $RefreshBtn.TabIndex = 6
    $RefreshBtn.Text = "Refresh"
    $RefreshBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $RefreshBtn.UseVisualStyleBackColor = $True
    $RefreshBtn.Enabled = $false
    $RefreshBtn.add_Click($RefreshBtn_OnClick)
     
    $EasySnapForm.Controls.Add($RefreshBtn)
    #End Refresh Button
     
    #Start Reset Button
    $ResetBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 515
    $System_Drawing_Point.Y = 427
    $ResetBtn.Location = $System_Drawing_Point
    $ResetBtn.Name = "ResetBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $ResetBtn.Size = $System_Drawing_Size
    $ResetBtn.TabIndex = 6
    $ResetBtn.Text = "Reset"
    $ResetBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $ResetBtn.UseVisualStyleBackColor = $True
    $ResetBtn.Enabled = $false
    $ResetBtn.add_Click($ResetBtn_OnClick)
     
    $EasySnapForm.Controls.Add($ResetBtn)
    #End Reset Button
     
    #Start Exit Button
    $ExitBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 622
    $System_Drawing_Point.Y = 427
    $ExitBtn.Location = $System_Drawing_Point
    $ExitBtn.Name = "ExitBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $ExitBtn.Size = $System_Drawing_Size
    $ExitBtn.TabIndex = 6
    $ExitBtn.Text = "Exit"
    $ExitBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $ExitBtn.UseVisualStyleBackColor = $True
    $ExitBtn.add_Click($ExitBtn_OnClick)
     
    $EasySnapForm.Controls.Add($ExitBtn)
    #End Delete Button
     
     
    #endregion Generated Form Code
     
    #Save the initial state of the form
    $InitialFormWindowState1 = $EasySnapForm.WindowState
    #Init the OnLoad event to correct the initial state of the form
    $EasySnapForm.add_Load($OnLoadForm_StateCorrection)
    #Show the Form
    $EasySnapForm.ShowDialog()| Out-Null
     
    } #End Function
     
    #Generated Snapshot Form Function
    function GenerateSnapForm {
     
    #region Import the Assemblies
    [reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
    [reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
    #endregion
     
    #region Generated Form Objects
    $TakeSnapForm = New-Object System.Windows.Forms.Form
    $FormHeader2 = new-object System.Windows.Forms.Label
    $InfoLabel = New-Object System.Windows.Forms.Label
    $VMListBox = New-Object System.Windows.Forms.CheckedListBox
    $SnapNameLbl = New-Object System.Windows.Forms.Label
    $SnapNameComboBox = New-Object System.Windows.Forms.ComboBox
    $CreatorLbl = New-Object System.Windows.Forms.Label
    $CreatorTxtBox = New-Object System.Windows.Forms.TextBox
    $RetentionLbl = New-Object System.Windows.Forms.Label
    $RetentionComboBox = New-Object System.Windows.Forms.ComboBox
    $ChangeNoLbl = New-Object System.Windows.Forms.Label
    $ChangeNoTxtBox = New-Object System.Windows.Forms.TextBox
    $FindTxtBox = New-Object System.Windows.Forms.TextBox
    $FindBtn = New-Object System.Windows.Forms.Button
    $ResetFindBtn = New-Object System.Windows.Forms.Button
    $FindLbl = New-Object System.Windows.Forms.Label
    $TakeSnapBtn = New-Object System.Windows.Forms.Button
    $ExitBtn2 = New-Object System.Windows.Forms.Button
    $InitialFormWindowState2 = New-Object System.Windows.Forms.FormWindowState
    #endregion Generated Form Objects
     
    $FindBtn_OnClick=
    {
    #TODO: Place custom script here
     
    If($FindTxtBox.Text -ne "")
    {
     
    If($VMListBox.CheckedItems.Count -eq 0)
    {
    $VMListBox.Items.Clear()
    }
    Else
    {
    $CheckedVMs = @()
    Foreach($VM in $VMListBox.CheckedItems)
    {
    $CheckedVMs += $VM
    }
     
    $VMListBox.Items.Clear()
     
    Foreach($CheckedVM in $CheckedVMs)
    {
    [void]$VMListBox.items.add($CheckedVM)
    $VMListBox.SetItemChecked($VMListBox.items.IndexOf($CheckedVM),$true)
    }
    }
     
    $BeforeCount = $VMListBox.Items.Count
     
    Get-VM -Name $FindTxtBox.Text -ErrorAction SilentlyContinue | % { [void]$VMListBox.items.add($_.Name) }
     
    $AfterCount = $VMListBox.Items.Count
     
        If($AfterCount -eq $BeforeCount)
        {
        [reflection.assembly]::loadwithpartialname('system.windows.forms')
        [system.Windows.Forms.MessageBox]::show('No results found.')
        }
    }
    }
     
    $ResetFindBtn_OnClick=
    {
    #TODO: Place custom script here
    $VMListBox.Items.Clear()
    Get-VM | % { [void]$VMListBox.items.add($_.Name) }
    }
     
    $TakeSnapBtn_OnClick=
    {
    #TODO: Place custom script here
    $CheckedVMs = $VMListBox.CheckedItems
     
    If($CheckedVMs.count -eq 0)
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show('No VM Selected.')
    }
    Else
    {
    $SnapName = $SnapNameComboBox.Text
    $CreatorID = $CreatorTxtBox.Text
    $Retention = $RetentionCombobox.SelectedItem
    $DeletionDate = (Get-Date).AddDays($Retention).ToShortDateString()
    $ChangeNo = $ChangeNoTxtBox.Text
    $SnapDesc = $CreatorID + "_" + $ChangeNo + "_" + $DeletionDate
     
    If(($SnapName -eq "") -or ($ChangeNo -eq ""))
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show('Please make sure that you have entered a Snapshot Name, Change Number and a Retention Period.')
    }
    ElseIf(($Retention -lt 1) -or ($Retention -gt 14))
    {
    [reflection.assembly]::loadwithpartialname('system.windows.forms')
    [system.Windows.Forms.MessageBox]::show('Retention period must be between 1 and 14 days.')
    }
    Else
    {
    foreach($CheckedVM in $CheckedVMs){
    New-Snapshot -VM(Get-VM -Name $CheckedVM) -Name $SnapName -Description $SnapDesc -Confirm:$false -RunAsync
    }
     
    $a = new-object -comobject wscript.shell
    $intAnswer = $a.popup("Task submitted successfully. Please check the task list in the vCenter console to view the progress. Do you want to create more
     
    snapshots?", 0,"Create Snapshots",4)
        If($intAnswer -eq 6) {
            $VMListBox.Items.Clear()
            Get-VM | % { [void]$VMListBox.items.add($_.Name) }
            $SnapNameComboBox.Text = ""
            $CreatorTxtBox.Text = ""
            $RetentionComboBox.Text = ""
            $ChangeNoTxtBox.Text = ""
            $FindTxtBox.Text = ""
        }Else {
            $TakeSnapForm.close()
        }
     
    }
    }
    }
     
    $ExitBtn2_OnClick=
    {
    #TODO: Place custom script here
    $TakeSnapForm.close()
    }
     
    #----------------------------------------------
    #region Generated Form Code
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 462
    $System_Drawing_Size.Width = 734
    $TakeSnapForm.ClientSize = $System_Drawing_Size
    $TakeSnapForm.DataBindings.DefaultDataSourceUpdateMode = 0
    $TakeSnapForm.Name = "TakeSnapForm"
    $TakeSnapForm.Text = "Snapshot Creation Form"
    $TakeSnapForm.StartPosition = "CenterScreen"
    $TakeSnapForm.FormBorderStyle = "FixedDialog"
    $TakeSnapForm.MaximizeBox = $false
    $TakeSnapForm.MinimizeBox = $false
     
    #Start Form Header
    $FormHeader2.Font = new-object System.Drawing.Font("Tahoma",10,[System.Drawing.FontStyle]::Bold)
    $FormHeader2.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
    $FormHeader2.Text = 'Easy Snapshot Tool'
    $FormHeader2.Location = new-object System.Drawing.Point(15,15)
    $FormHeader2.Size = new-object System.Drawing.Size(230, 20)
     
    $TakeSnapForm.Controls.Add($FormHeader2)
    #End Form Header
     
    # Start Info Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 600
    $System_Drawing_Size.Height = 20
    $InfoLabel.Size = $System_Drawing_Size
    $InfoLabel.Font = new-object System.Drawing.Font("Tahoma",10)
    $InfoLabel.Text = 'Use this form to take a snapshot of multiple virtual machines at the same time.'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 15
    $System_Drawing_Point.Y = 50
    $InfoLabel.Location = $System_Drawing_Point
    $InfoLabel.DataBindings.DefaultDataSourceUpdateMode = 0
    $InfoLabel.Name = 'InfoLabel'
     
    $TakeSnapForm.Controls.Add($InfoLabel)
    # End Info Label
     
    # Start VM List Box
    $VMListBox.TabIndex = 0
    $VMListBox.FormattingEnabled = $True
    $VMListBox.CheckOnClick = $True
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 200
    $System_Drawing_Size.Height = 330
    $VMListBox.Size = $System_Drawing_Size
    $VMListBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $VMListBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $VMListBox.Name = 'VMListBox'
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 13
    $System_Drawing_Point.Y = 90
    $VMListBox.Location = $System_Drawing_Point
    $VMListBox.MultiColumn = $False
    $VMListBox.Sorted = $True
    $VMListBox.HorizontalScrollbar = $True
     
    $TakeSnapForm.Controls.Add($VMListBox)
     
    #Get VMs in the selected vCenter
    Get-VM | % { [void]$VMListBox.items.add($_.Name) }
    # End VM List Box
     
    # Start Snap Name Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 400
    $System_Drawing_Size.Height = 20
    $SnapNameLbl.Size = $System_Drawing_Size
    $SnapNameLbl.Font = new-object System.Drawing.Font("Tahoma",8,[System.Drawing.FontStyle]::Bold)
    $SnapNameLbl.Text = 'Snapshot Name:'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 90
    $SnapNameLbl.Location = $System_Drawing_Point
    $SnapNameLbl.DataBindings.DefaultDataSourceUpdateMode = 0
    $SnapNameLbl.Name = 'SnapNameLbl'
     
    $TakeSnapForm.Controls.Add($SnapNameLbl)
    # End Snap Name Label
     
    # Start Snap Name Combobox
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 200
    $System_Drawing_Size.Height = 20
    $SnapNameComboBox.Size = $System_Drawing_Size
    $SnapNameComboBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $SnapNameComboBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $SnapNameComboBox.Name = 'SnapNameComboBox'
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 110
    $SnapNameComboBox.Location = $System_Drawing_Point
    $SnapNameComboBox.TabIndex = 1
     
    $SnapshotNames = @("Patching","Hardening","Application Installation","Testing","Other")
    foreach($SnapshotName in $SnapshotNames)
    {
      $SnapNameComboBox.Items.add($SnapshotName)
    }
     
    $TakeSnapForm.Controls.Add($SnapNameComboBox)
    # End Snap Name Combobox
     
    # Start Creator Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 95
    $System_Drawing_Size.Height = 20
    $CreatorLbl.Size = $System_Drawing_Size
    $CreatorLbl.Font = new-object System.Drawing.Font("Tahoma",8,[System.Drawing.FontStyle]::Bold)
    $CreatorLbl.Text = 'Created By:'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 150
    $CreatorLbl.Location = $System_Drawing_Point
    $CreatorLbl.DataBindings.DefaultDataSourceUpdateMode = 0
    $CreatorLbl.Name = 'CreatorLbl'
     
    $TakeSnapForm.Controls.Add($CreatorLbl)
    # End Creator Label
     
    # Start Creator Textbox
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 70
    $System_Drawing_Size.Height = 20
    $CreatorTxtBox.Size = $System_Drawing_Size
    $CreatorTxtBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $CreatorTxtBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $CreatorTxtBox.Name = 'CreatorTxtBox'
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 170
    $CreatorTxtBox.Location = $System_Drawing_Point
     
    $TakeSnapForm.Controls.Add($CreatorTxtBox)
    $CreatorTxtBox.Text = [Environment]::UserName
    $CreatorTxtBox.Enabled = $false
    # End Creator Textbox
     
    # Start Retention Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 400
    $System_Drawing_Size.Height = 20
    $RetentionLbl.Size = $System_Drawing_Size
    $RetentionLbl.Font = new-object System.Drawing.Font("Tahoma",8,[System.Drawing.FontStyle]::Bold)
    $RetentionLbl.Text = 'Retention Period (Max 14 days):'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 210
    $RetentionLbl.Location = $System_Drawing_Point
    $RetentionLbl.DataBindings.DefaultDataSourceUpdateMode = 0
    $RetentionLbl.Name = 'RetentionLbl'
     
    $TakeSnapForm.Controls.Add($RetentionLbl)
    # End Retention Label
     
    # Start Retention ComboBox
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 50
    $System_Drawing_Size.Height = 20
    $RetentionComboBox.Size = $System_Drawing_Size
    $RetentionComboBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $RetentionComboBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $RetentionComboBox.Name = 'RetentionComboBox'
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 230
    $RetentionComboBox.Location = $System_Drawing_Point
    $RetentionComboBox.TabIndex = 1
     
    $RetentionDays = @(1,2,3,4,5,6,7,8,9,10,11,12,13,14)
    foreach($RetentionDay in $RetentionDays)
    {
      $RetentionComboBox.Items.add($RetentionDay)
    }
     
    $TakeSnapForm.Controls.Add($RetentionComboBox)
    # End Retention ComboBox
     
    # Start Change No Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 300
    $System_Drawing_Size.Height = 20
    $ChangeNoLbl.Size = $System_Drawing_Size
    $ChangeNoLbl.Font = new-object System.Drawing.Font("Tahoma",8,[System.Drawing.FontStyle]::Bold)
    $ChangeNoLbl.Text = 'Change Number (e.g. C12345 or BAU):'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 270
    $ChangeNoLbl.Location = $System_Drawing_Point
    $ChangeNoLbl.DataBindings.DefaultDataSourceUpdateMode = 0
    $ChangeNoLbl.Name = 'ChangeNoLbl'
     
    $TakeSnapForm.Controls.Add($ChangeNoLbl)
    # End Change No Label
     
    # Start Change No Textbox
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 70
    $System_Drawing_Size.Height = 20
    $ChangeNoTxtBox.Size = $System_Drawing_Size
    $ChangeNoTxtBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $ChangeNoTxtBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $ChangeNoTxtBox.Name = 'ChangeNoTxtBox'
    $ChangeNoTxtBox.TabIndex = 2
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 290
    $ChangeNoTxtBox.Location = $System_Drawing_Point
     
    $TakeSnapForm.Controls.Add($ChangeNoTxtBox)
    # End Change No Textbox
     
    # Start Find Textbox
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 100
    $System_Drawing_Size.Height = 20
    $FindTxtBox.Size = $System_Drawing_Size
    $FindTxtBox.Font = new-object System.Drawing.Font("Tahoma",8)
    $FindTxtBox.DataBindings.DefaultDataSourceUpdateMode = 0
    $FindTxtBox.Name = 'FindTxtBox'
    $FindTxtBox.TabIndex = 3
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 340
    $FindTxtBox.Location = $System_Drawing_Point
     
    $TakeSnapForm.Controls.Add($FindTxtBox)
    # End Find Textbox
     
    #Start Find Button
    $TakeSnapBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 355
    $System_Drawing_Point.Y = 340
    $FindBtn.Location = $System_Drawing_Point
    $FindBtn.Name = "FindBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 20
    $System_Drawing_Size.Width = 50
    $FindBtn.Size = $System_Drawing_Size
    $FindBtn.TabIndex = 4
    $FindBtn.Text = "Find"
    $FindBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $FindBtn.UseVisualStyleBackColor = $True
    $FindBtn.add_Click($FindBtn_OnClick)
     
    $TakeSnapForm.Controls.Add($FindBtn)
    #End Find Button
     
    #Start Reset Find Button
    $TakeSnapBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 410
    $System_Drawing_Point.Y = 340
    $ResetFindBtn.Location = $System_Drawing_Point
    $ResetFindBtn.Name = "ResetFindBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 20
    $System_Drawing_Size.Width = 50
    $ResetFindBtn.Size = $System_Drawing_Size
    $ResetFindBtn.TabIndex = 5
    $ResetFindBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $ResetFindBtn.Text = "Reset"
    $ResetFindBtn.UseVisualStyleBackColor = $True
    $ResetFindBtn.add_Click($ResetFindBtn_OnClick)
     
    $TakeSnapForm.Controls.Add($ResetFindBtn)
    #End Reset Find Button
     
    # Start Find Label
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Width = 300
    $System_Drawing_Size.Height = 20
    $FindLbl.Size = $System_Drawing_Size
    $FindLbl.Font = new-object System.Drawing.Font("Tahoma",8,[System.Drawing.FontStyle]::Bold)
    $FindLbl.Text = '(Note: Use * for Wildcards)'
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 250
    $System_Drawing_Point.Y = 365
    $FindLbl.Location = $System_Drawing_Point
    $FindLbl.DataBindings.DefaultDataSourceUpdateMode = 0
    $FindLbl.Name = 'FindLbl'
     
    $TakeSnapForm.Controls.Add($FindLbl)
    # End Find Label
     
    #Start Take Snap Button
    $TakeSnapBtn.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 515
    $System_Drawing_Point.Y = 427
    $TakeSnapBtn.Location = $System_Drawing_Point
    $TakeSnapBtn.Name = "TakeSnapBtn"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $TakeSnapBtn.Size = $System_Drawing_Size
    $TakeSnapBtn.TabIndex = 6
    $TakeSnapBtn.Text = "Take Snapshot"
    $TakeSnapBtn.Font = new-object System.Drawing.Font("Tahoma",8)
    $TakeSnapBtn.UseVisualStyleBackColor = $True
    $TakeSnapBtn.add_Click($TakeSnapBtn_OnClick)
     
    $TakeSnapForm.Controls.Add($TakeSnapBtn)
    #End Take Snap Button
     
    #Start Exit Button
    $ExitBtn2.DataBindings.DefaultDataSourceUpdateMode = 0
     
    $System_Drawing_Point = New-Object System.Drawing.Point
    $System_Drawing_Point.X = 622
    $System_Drawing_Point.Y = 427
    $ExitBtn2.Location = $System_Drawing_Point
    $ExitBtn2.Name = "ExitBtn2"
    $System_Drawing_Size = New-Object System.Drawing.Size
    $System_Drawing_Size.Height = 23
    $System_Drawing_Size.Width = 100
    $ExitBtn2.Size = $System_Drawing_Size
    $ExitBtn2.TabIndex = 7
    $ExitBtn2.Text = "Exit"
    $ExitBtn2.Font = new-object System.Drawing.Font("Tahoma",8)
    $ExitBtn2.UseVisualStyleBackColor = $True
    $ExitBtn2.add_Click($ExitBtn2_OnClick)
     
    $TakeSnapForm.Controls.Add($ExitBtn2)
    #End Exit Button
     
    #endregion Generated Form Code
     
    #Save the initial state of the form
    $InitialFormWindowState2 = $TakeSnapForm.WindowState
    #Init the OnLoad event to correct the initial state of the form
    $TakeSnapForm.add_Load($OnLoadForm_StateCorrection)
    #Show the Form
    $TakeSnapForm.ShowDialog()| Out-Null
     
    } #End Function
     
    #Call the Function
    GenerateForm