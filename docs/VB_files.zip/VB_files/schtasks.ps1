#'''''''''''''''''''''''''''''''''''''
#' Department SSO    04/24/2014      '
#' Created by Vladislav Nechayev     '
#'''''''''''''''''''''''''''''''''''''
#Usage:
#Replace NAME with the server name you need to transfer scheduled tasks from
$sch = New-Object -ComObject("Schedule.Service")

$sch.Connect("NAME")

$tasks = $sch.GetFolder("\").GetTasks(0)

md -Path 'C:\Exported_scheduled_task'

$outfile_temp = "C:\Exported_scheduled_task\{0}.xml"

$tasks | %{
  $xml = $_.Xml
  $task_name = $_.Name
  $outfile = $outfile_temp -f $task_name
  $xml | Out-File $outfile
}