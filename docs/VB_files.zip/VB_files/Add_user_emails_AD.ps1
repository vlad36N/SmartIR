﻿# Load ActiveDirectory module
Import-Module ActiveDirectory
# Get saved creds securely for this session, change path for Credential.xml
$Creds = Get-VICredentialStoreItem -Host $x -File "C:\Program Files (x86)\VMware\Infrastructure\vSphere PowerCLI\Scripts\Delta_inventory\Credential.xml"

$Pass = $Creds.Password
$Pass = $Pass  -replace "'", "";

# Run cmdlet as the admin user
New-ADUser $Creds.User -Password $Pass -ErrorAction SilentlyContinue


$users = Import-Csv -Path C:\users.csv                   
foreach ($user in $users) 
{Get-ADUser -Filter "SamAccountName -eq '$($user.samaccountname)'" | Set-ADUser -mail $($User.email)}