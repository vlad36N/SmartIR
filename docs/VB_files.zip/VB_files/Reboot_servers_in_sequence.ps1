oreach($server in $servers){
     Try{
          Restart-Computer -computer $server -Wait -For WMI -ea Stop
          Writ-Host "$server restarted successfully" -fore green
    }
    Catch{
        # what to do in case of failure or timeout.
        Write-Host "$server restaqrt failed" -fore red
    }
}