<#
Department SSO    06/10/2014
Created by Vladislav Nechayev

Script search and delete old virus def folders

#>
$LogPath = "C:\Program Files\Common Files\Symantec Shared\VirusDefs\"
$LogName = "Delete_folders.log"
$sFullPath = $LogPath + "\" + $LogName

Add-Content -Path $sFullPath -Value "***************************************************************************************************"
Add-Content -Path $sFullPath -Value "Started processing at [$([DateTime]::Now)]."
Add-Content -Path $sFullPath -Value "***************************************************************************************************"

Clear-Host
Set-location "C:\Program Files\Common Files\Symantec Shared\VirusDefs"
$x = Get-Content "C:\Program Files\Common Files\Symantec Shared\VirusDefs\definfo.dat" | Select-Object -Last 1
$y = Get-ChildItem "C:\Program Files\Common Files\Symantec Shared\VirusDefs" | Where-Object {$_.Name -like "2014*"}
foreach ($z in $y)
    {
        If ($x -notmatch $z.name)
            {
                 Remove-Item $z.name -Recurse
                 Add-Content -Path $sFullPath -Value "Folders deleted : $z"
                
            }    
    }
    
Add-Content -Path $sFullPath -Value ""
Add-Content -Path $sFullPath -Value "***************************************************************************************************"
Add-Content -Path $sFullPath -Value "Finished processing at [$([DateTime]::Now)]."
Add-Content -Path $sFullPath -Value "***************************************************************************************************"