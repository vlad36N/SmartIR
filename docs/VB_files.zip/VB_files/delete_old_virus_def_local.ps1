<#
Department SSO    06/10/2014
Created by Vladislav Nechayev

Script search and delete old virus def folders

#>
$LogPath = "C:\Test\Test\"
$LogName = "Delete_folders.log"
$sFullPath = $LogPath + "\" + $LogName

Add-Content -Path $sFullPath -Value "***************************************************************************************************"
Add-Content -Path $sFullPath -Value "Started processing at [$([DateTime]::Now)]."
Add-Content -Path $sFullPath -Value "***************************************************************************************************"

Clear-Host
Set-location "C:\Test\Test"
$x = Get-Content "C:\Test\Test\definfo.dat" | Select-Object -Last 1
$y = Get-ChildItem "C:\Test\Test" | Where-Object {$_.Name -like "2014*"}
foreach ($z in $y)
    {
        If ($x -notmatch $z.name)
            {
                 Remove-Item $z.name -Recurse
                 Add-Content -Path $sFullPath -Value "Folders deleted : $z"
                
            }    
    }
    
Add-Content -Path $sFullPath -Value ""
Add-Content -Path $sFullPath -Value "***************************************************************************************************"
Add-Content -Path $sFullPath -Value "Finished processing at [$([DateTime]::Now)]."
Add-Content -Path $sFullPath -Value "***************************************************************************************************"