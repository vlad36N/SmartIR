using System;
class SystemInfo {
    
    static void main() {
        Console.WriteLine("");
        Console.WriteLine("Current User");
        Console.WriteLine(Environment.UserName);
        Console.WriteLine("");
        Console.WriteLine("Name of the Machine");
        Console.WriteLine(Environment.MachineName);
        Console.WriteLine("");
        Console.WriteLine("OS version");
        Console.WriteLine(Environment.OSVersion);
        Console.WriteLine("");
        Console.WriteLine("System Directory");
        Console.WriteLine(Environment.SystemDirectory);
        Console.WriteLine("");
        Console.WriteLine("TMP Folder");
        Console.WriteLine(Environment.GetEnvironmentVariable("TMP"));
        Console.WriteLine("");
        Console.WriteLine("Class Path");
        Console.WriteLine(Environment.GetEnvironmentVariable("ClassPath"));
        Console.WriteLine("");
        Console.readLine();
    }
}