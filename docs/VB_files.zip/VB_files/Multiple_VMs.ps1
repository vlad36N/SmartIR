<#
Create multiple VMs
Department SSO    06/10/2014
Created by Vladislav Nechayev
#>
# Specify vCenter Server, vCenter Server username and vCenter Server user password
$vCenter=�vsphere50�
#$vCenterUser=�CONED\Nechayevv-sso�
#$vCenterUserPassword=��
#
# Specify number of VMs you want to create
$vm_count = �2�
#
# Specify the VM you want to clone
#$clone = �IMG2008R2�
#
# Specify the Customization Specification to use
#$customspecification=�VCDX56-customization�
#
#Template
$OS_Template = get-template IMG2008R2 | select-object -first 1
# Specify the datastore or datastore cluster placement
$ds = �v2252a-nonProd2�
#
# Specify vCenter Server Virtual Machine & Templates folder
$Folder = �Images�
#
# Specify the vSphere Cluster
$Cluster = �vm-fex�
#
# Specify the VM name to the left of the � sign
$VM_prefix = �TestSvr-�
#
# End of user input parameters
#_______________________________________________________
#
write-host �Connecting to vCenter Server $vCenter� -foreground green
#Connect-viserver $vCenter -user $vCenterUser -password $vCenterUserPassword -WarningAction 0
Connect-VIServer $vCenter -ErrorAction SilentlyContinue
1..$vm_count | foreach {
$y=�{0:D2}� -f $_
$VM_name= $VM_prefix + $y
$ESXi=Get-Cluster $Cluster | Get-VMHost -state connected | Get-Random
write-host �Creation of VM $VM_name initiated� -foreground green
#New-VM -Name $VM_Name -VM $clone -VMHost $ESXi -Datastore $ds -Location $Folder -OSCustomizationSpec $customspecification -RunAsync
#New-VM -Name $VM_Name -Template IMG2008R2 -VMHost $ESXi -Datastore $ds -Location $Folder -RunAsync
New-VM -Name $VM_Name -Template $OS_Template -VMHost $ESXi -Datastore $ds -RunAsync
write-host �Power On of the  VM $VM_name initiated�  -foreground green
Start-VM -VM $VM_name -confirm:$false -RunAsync
}
Disconnect-VIServer $vCenter -Confirm:$false