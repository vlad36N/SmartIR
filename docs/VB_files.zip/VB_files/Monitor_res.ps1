#Get Resolution
Add-Type -AssemblyName System.Windows.Forms
$res = [System.Windows.Forms.Screen]::AllScreens | Where-Object {$_.Primary -eq 'True'} | Select-Object WorkingArea
if (($res -split ',')[3].Substring(10,1) -match '}') {$heightend = 3}
else {$heightend = 4}
$w = ($res -split ',')[2].Substring(6)
$h = ($res -split ',')[3].Substring(7,$heightend)
'Screen Resolution: ' + $w + 'x' + $h