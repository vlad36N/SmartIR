#read 1 server
Connect-VIServer Vsphere50

Get-VM | Select Name, @{N="Datacenter";E={Get-Cluster -VM $_}}, @{N="Cluster";E={Get-Cluster -VM $_}}, @{N="ESX Host";E={Get-VMHost -VM $_}}, @{N="Datastore";E={Get-Datastore -VM $_}}, @{N="OS";E={$_.guest.OSFullname}} | Export-Csv -NoTypeInformation C:\Vsphere50.csv

Disconnect-VIServer Vsphere50 -Confirm:$false
#read 2 server
Connect-VIServer Vspherei

Get-VM | Select Name, @{N="Datacenter";E={Get-Cluster -VM $_}}, @{N="Cluster";E={Get-Cluster -VM $_}}, @{N="ESX Host";E={Get-VMHost -VM $_}}, @{N="Datastore";E={Get-Datastore -VM $_}}, @{N="OS";E={$_.guest.OSFullname}} | Export-Csv -NoTypeInformation C:\Vspherei.csv

Disconnect-VIServer Vspherei -Confirm:$false
#read 3 server
Connect-VIServer Vsphere

Get-VM | Select Name, @{N="Datacenter";E={Get-Cluster -VM $_}}, @{N="Cluster";E={Get-Cluster -VM $_}}, @{N="ESX Host";E={Get-VMHost -VM $_}}, @{N="Datastore";E={Get-Datastore -VM $_}}, @{N="OS";E={$_.guest.OSFullname}} | Export-Csv -NoTypeInformation C:\Vsphere.csv

Disconnect-VIServer Vsphere -Confirm:$false
#read 4 server
Connect-VIServer Vicenter

Get-VM | Select Name, @{N="Datacenter";E={Get-Cluster -VM $_}}, @{N="Cluster";E={Get-Cluster -VM $_}}, @{N="ESX Host";E={Get-VMHost -VM $_}}, @{N="Datastore";E={Get-Datastore -VM $_}}, @{N="OS";E={$_.guest.OSFullname}} | Export-Csv -NoTypeInformation C:\Vicenter.csv

Disconnect-VIServer Vicenter -Confirm:$false
#read 5 server
Connect-VIServer ESX

Get-VM | Select Name, @{N="Datacenter";E={Get-Cluster -VM $_}}, @{N="Cluster";E={Get-Cluster -VM $_}}, @{N="ESX Host";E={Get-VMHost -VM $_}}, @{N="Datastore";E={Get-Datastore -VM $_}}, @{N="OS";E={$_.guest.OSFullname}} | Export-Csv -NoTypeInformation C:\ESX.csv

Disconnect-VIServer ESX -Confirm:$false
#read 6 server
Connect-VIServer Itplab-Dserv

Get-VM | Select Name, @{N="Datacenter";E={Get-Cluster -VM $_}}, @{N="Cluster";E={Get-Cluster -VM $_}}, @{N="ESX Host";E={Get-VMHost -VM $_}}, @{N="Datastore";E={Get-Datastore -VM $_}}, @{N="OS";E={$_.guest.OSFullname}} | Export-Csv -NoTypeInformation C:\Itplab-Dserv.csv

Disconnect-VIServer Itplab-Dserv -Confirm:$false